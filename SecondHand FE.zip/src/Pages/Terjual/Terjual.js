import React from "react";
import TerjualPage from "../../Components/Terjual/Terjual";
const Terjual = () => {
	return (
		<div>
			<TerjualPage />
		</div>
	);
};

export default Terjual;
