import React from "react";
import RegisterPage from "../../Components/register/register";

export const Register = () => {
	return (
		<div>
			<RegisterPage />
		</div>
	);
};

export default Register;
