import React from "react";
import WishlistPage from "../../Components/Wishlist/Whistlist";

const Wishlist = () => {
	return (
		<div>
			<WishlistPage />
		</div>
	);
};

export default Wishlist;
