import React from "react";
import BarangDiminati from "../../Components/SellerDaftarJual/Diminati/BarangDiminati";

const DaftarJual = () => {
	return (
		<div>
			<BarangDiminati />
		</div>
	);
};

export default DaftarJual;
