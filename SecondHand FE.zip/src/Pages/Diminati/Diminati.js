import React from "react";
import DiminatiPage from "../../Components/Diminati/Diminati";

const Diminati = () => {
	return (
		<div>
			<DiminatiPage />
		</div>
	);
};

export default Diminati;
