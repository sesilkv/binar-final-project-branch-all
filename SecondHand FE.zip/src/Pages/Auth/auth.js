import React from "react";
import AuthPage from "../../Components/Auth/Auth";

const Auth = () => {
	return (
		<div>
			<AuthPage />
		</div>
	);
};

export default Auth;
