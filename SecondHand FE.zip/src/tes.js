import React from "react";

function tes() {
	return <h1>tes</h1>;
}

export default tes;
