import React from "react";
import "./Login.css";

const LoginHeader = () => {
	return (
		<div>
			<img src="/SVG/arrow_left.svg" alt="arrow icon" className=" arrow-svg" />
		</div>
	);
};

export default LoginHeader;
