import React from "react";
import "./DiminatiCard.css";
const DiminatiCard = () => {
	return (
		<div>
			<h1>ini diminati halaman</h1>
		</div>
	);
};

export default DiminatiCard;
