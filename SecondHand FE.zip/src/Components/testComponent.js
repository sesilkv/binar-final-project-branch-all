import React from "react";

const testComponent = () => {
	return <div>testComponent</div>;
};

export default testComponent;
