import React from "react";
import "./daftarJual.css";

const slider = () => {
	return (
		<div>
			<button className="btn_swiper">Produk</button>
			<button className="btn_swiper">Diminati</button>
			<button className="btn_swiper">Terjual</button>
		</div>
	);
};

export default slider;
