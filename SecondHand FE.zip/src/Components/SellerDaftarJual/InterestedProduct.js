import React from 'react';
import "./daftarJual.css";

const InterestedProduct = () => {
  return (
    <div className='container'>
        <div className='box-interested text-center'>
            <img src='/images/interested.png' alt='interested-image'/>
            <p className='py-4'>Belum ada produkmu yang diminati nih, 
                sabar ya rejeki nggak kemana kok</p>
        </div>
    </div>
  )
}

export default InterestedProduct;