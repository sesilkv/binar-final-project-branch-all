import React from "react";
import "./Register.css";

const RegisterImage = () => {
	return (
		<div className="login_left col-12 col-lg-5 p-0">
			<img src="/SVG/login_img.svg" className="d-none d-lg-block register_img" alt=" login" />
		</div>
	);
};

export default RegisterImage;
