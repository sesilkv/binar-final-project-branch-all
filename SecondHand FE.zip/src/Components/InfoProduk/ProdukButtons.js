import React from "react";
import { Link } from "react-router-dom";

const ProdukButtons = () => {
	return (
		<div class="d-flex produk_btnGroup">
			<div className="">
				<button class="produk_btn1 text_reguler" type="button">
					<Link to={`/seller/${id}`}>Preview</Link>
				</button>
			</div>
			<div className="">
				<button class="produk_btn2 text_reguler" type="button">
					<Link to='/daftarjual'>Terbitkan</Link>
				</button>
			</div>
		</div>
	);
};

export default ProdukButtons;
