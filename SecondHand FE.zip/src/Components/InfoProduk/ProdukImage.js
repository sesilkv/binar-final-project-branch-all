import React from "react";
import { AiOutlinePlusCircle } from "react-icons/ai";

const ProdukImage = () => {
	return (
		<div className="infoProduk_img">
			<AiOutlinePlusCircle className="infoProduk_icon" />
		</div>
	);
};

export default ProdukImage;
